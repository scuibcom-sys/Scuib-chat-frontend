import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Category = string;

export type Skill = string;

export function getOnboardingUserKey(
  user?: { email?: string | null; id?: string | null } | null,
  fallbackIdentifier?: string | null,
) {
  const email = user?.email?.trim().toLowerCase();
  if (email) return email;

  const fallback = fallbackIdentifier?.trim().toLowerCase();
  if (fallback) return fallback;

  const id = user?.id?.trim().toLowerCase();
  return id || null;
}

interface ProfileSetupState {
  fullName: string;
  username: string;
  emailAddress: string;
  bio: string;
  linkedin: string;
  xHandle: string;
  portfolio: string;
  avatarPreview: string | null;
  selectedCategories: Category[];
  selectedSkills: Skill[];
  currentStep: number;
  remoteProfileMissing: boolean;
  onboardingCompletedByUser: Record<string, boolean>;
  setFullName: (fullName: string) => void;
  setUsername: (username: string) => void;
  setEmailAddress: (emailAddress: string) => void;
  setBio: (bio: string) => void;
  setLinkedin: (linkedin: string) => void;
  setXHandle: (xHandle: string) => void;
  setPortfolio: (portfolio: string) => void;
  setAvatarPreview: (avatarPreview: string | null) => void;
  hydrateProfile: (profile: {
    fullName?: string;
    username?: string;
    emailAddress?: string;
    bio?: string;
    linkedin?: string;
    xHandle?: string;
    portfolio?: string;
    avatarPreview?: string | null;
    selectedCategories?: Category[];
    selectedSkills?: Skill[];
  }) => void;
  setSelectedCategories: (categories: Category[]) => void;
  setSelectedSkills: (skills: Skill[]) => void;
  setRemoteProfileMissing: (remoteProfileMissing: boolean) => void;
  hasCompletedOnboarding: (userKey: string | null | undefined) => boolean;
  markOnboardingCompleted: (userKey: string | null | undefined) => void;
  toggleCategory: (category: Category) => void;
  toggleSkill: (skill: Skill) => void;
  removeCategory: (category: Category) => void;
  removeSkill: (skill: Skill) => void;
  setStep: (step: number) => void;
  nextStep: () => void;
  prevStep: () => void;
  reset: () => void;
}

const defaultState = {
  fullName: "",
  username: "",
  emailAddress: "",
  bio: "",
  linkedin: "",
  xHandle: "",
  portfolio: "",
  avatarPreview: null,
  selectedCategories: [] as Category[],
  selectedSkills: [] as Skill[],
  currentStep: 1,
  remoteProfileMissing: false,
  onboardingCompletedByUser: {} as Record<string, boolean>,
};

export const useProfileSetupStore = create<ProfileSetupState>()(
  persist(
    (set, get) => ({
      ...defaultState,

      setFullName: (fullName) => set({ fullName }),
      setUsername: (username) => set({ username }),
      setEmailAddress: (emailAddress) => set({ emailAddress }),
      setBio: (bio) => set({ bio }),
      setLinkedin: (linkedin) => set({ linkedin }),
      setXHandle: (xHandle) => set({ xHandle }),
      setPortfolio: (portfolio) => set({ portfolio }),
      setAvatarPreview: (avatarPreview) => set({ avatarPreview }),

      hydrateProfile: (profile) =>
        set((state) => ({
          fullName: profile.fullName ?? state.fullName,
          username: profile.username ?? state.username,
          emailAddress: profile.emailAddress ?? state.emailAddress,
          bio: profile.bio ?? state.bio,
          linkedin: profile.linkedin ?? state.linkedin,
          xHandle: profile.xHandle ?? state.xHandle,
          portfolio: profile.portfolio ?? state.portfolio,
          avatarPreview:
            profile.avatarPreview === undefined
              ? state.avatarPreview
              : profile.avatarPreview,
          selectedCategories:
            profile.selectedCategories ?? state.selectedCategories,
          selectedSkills: profile.selectedSkills ?? state.selectedSkills,
        })),

      setSelectedCategories: (selectedCategories) => set({ selectedCategories }),
      setSelectedSkills: (selectedSkills) => set({ selectedSkills }),
      setRemoteProfileMissing: (remoteProfileMissing) =>
        set({ remoteProfileMissing }),
      hasCompletedOnboarding: (userKey) =>
        Boolean(userKey && get().onboardingCompletedByUser[userKey]),
      markOnboardingCompleted: (userKey) => {
        if (!userKey) return;

        set((state) => ({
          onboardingCompletedByUser: {
            ...state.onboardingCompletedByUser,
            [userKey]: true,
          },
        }));
      },

      toggleCategory: (category) => {
        const { selectedCategories } = get();
        if (selectedCategories.includes(category)) {
          set({
            selectedCategories: selectedCategories.filter(
              (currentCategory) => currentCategory !== category,
            ),
          });
        } else {
          set({ selectedCategories: [...selectedCategories, category] });
        }
      },

      toggleSkill: (skill) => {
        const { selectedSkills } = get();
        if (selectedSkills.includes(skill)) {
          set({
            selectedSkills: selectedSkills.filter(
              (currentSkill) => currentSkill !== skill,
            ),
          });
        } else {
          set({ selectedSkills: [...selectedSkills, skill] });
        }
      },

      removeCategory: (category) =>
        set((state) => ({
          selectedCategories: state.selectedCategories.filter(
            (currentCategory) => currentCategory !== category,
          ),
        })),

      removeSkill: (skill) =>
        set((state) => ({
          selectedSkills: state.selectedSkills.filter(
            (currentSkill) => currentSkill !== skill,
          ),
        })),

      setStep: (step) => set({ currentStep: step }),

      nextStep: () =>
        set((state) => ({
          currentStep: Math.min(3, state.currentStep + 1),
        })),

      prevStep: () =>
        set((state) => ({
          currentStep: Math.max(1, state.currentStep - 1),
        })),

      reset: () =>
        set((state) => ({
          ...defaultState,
          onboardingCompletedByUser: state.onboardingCompletedByUser,
        })),
    }),
    {
      name: "profile-setup-storage",
    },
  ),
);
